#!/usr/bin/env bash
echo "Packing to 'clean-cyn.tar.gz'..."
tar -czf ../clean-cyn.tar.gz * .env