# Hello!
This is an example page from CynthiaCMS.

If you are here because you just set up a new Cynthia instance, we have a page [to get you started](/p/getting/started/)!